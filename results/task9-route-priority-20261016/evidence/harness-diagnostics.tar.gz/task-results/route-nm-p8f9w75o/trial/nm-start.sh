set -eu
    mount -t tmpfs tmpfs /run
    mkdir -p /run/udev/data
    mount --bind /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/udev-data /run/udev/data
    mount -o remount,bind,ro /run/udev/data
    mount --bind /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/etcNM /etc/NetworkManager
    mount --bind /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/varlib /var/lib/NetworkManager
    mount --bind /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/empty /etc/netplan
    dbus-daemon --system --nofork --nopidfile --address=unix:abstract=wifi-route-54 > /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/dbus.log 2>&1 &
    export DBUS_SYSTEM_BUS_ADDRESS=unix:abstract=wifi-route-54
    exec strace -f -ttt -s 512 -e trace=sendmsg,recvmsg,ioctl -o /workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/nm.strace \
      NetworkManager --no-daemon --debug --config=/workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/nm.conf --config-dir=/workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/empty \
      --system-config-dir=/workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/empty --pid-file=/workspace/openpilot-wifi-validation/task-results/route-nm-p8f9w75o/trial/nm.pid --log-level=TRACE --log-domains=PLATFORM,IP4,DEVICE,DHCP4,CORE
    