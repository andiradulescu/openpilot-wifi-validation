set -eu
    mount -t tmpfs tmpfs /run
    mkdir -p /run/udev/data
    mount --bind /tmp/wifi-route-priority-20261016-1620/red-nm/udev-data /run/udev/data
    mount -o remount,bind,ro /run/udev/data
    mount --bind /tmp/wifi-route-priority-20261016-1620/red-nm/etcNM /etc/NetworkManager
    mount --bind /tmp/wifi-route-priority-20261016-1620/red-nm/varlib /var/lib/NetworkManager
    mount --bind /tmp/wifi-route-priority-20261016-1620/red-nm/empty /etc/netplan
    dbus-daemon --system --nofork --nopidfile --address=unix:path=/tmp/wifi-route-priority-20261016-1620/red-nm/bus.sock > /tmp/wifi-route-priority-20261016-1620/red-nm/dbus.log 2>&1 &
    export DBUS_SYSTEM_BUS_ADDRESS=unix:path=/tmp/wifi-route-priority-20261016-1620/red-nm/bus.sock
    exec strace -f -ttt -s 512 -e trace=sendmsg,recvmsg,ioctl -o /tmp/wifi-route-priority-20261016-1620/red-nm/nm.strace NetworkManager --no-daemon --debug --config=/tmp/wifi-route-priority-20261016-1620/red-nm/nm.conf --config-dir=/tmp/wifi-route-priority-20261016-1620/red-nm/empty --system-config-dir=/tmp/wifi-route-priority-20261016-1620/red-nm/empty --pid-file=/tmp/wifi-route-priority-20261016-1620/red-nm/nm.pid --log-level=TRACE --log-domains=PLATFORM,IP4,DEVICE,DHCP4,CORE
    