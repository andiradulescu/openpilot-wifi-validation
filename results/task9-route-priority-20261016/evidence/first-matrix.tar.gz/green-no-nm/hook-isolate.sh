#!/bin/sh
set -eu
mount --bind /tmp/wifi-route-priority-20261016-1620/green-no-nm/resolv.conf /run/systemd/resolve/stub-resolv.conf
if [ "no-nm" = no-nm ]; then
 mount -t tmpfs tmpfs /run
 mount --bind /tmp/wifi-route-priority-20261016-1620/green-no-nm/absent /usr/bin/nmcli
 mount --bind /tmp/wifi-route-priority-20261016-1620/green-no-nm/absent /usr/sbin/NetworkManager
 test ! -x /usr/bin/nmcli
 test ! -x /usr/sbin/NetworkManager
 test ! -S /run/dbus/system_bus_socket
fi
exec /tmp/wifi-route-priority-20261016-1620/green-no-nm/udhcpc.script "$1"
