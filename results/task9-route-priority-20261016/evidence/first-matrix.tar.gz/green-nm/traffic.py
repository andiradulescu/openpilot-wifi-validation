import socket,time
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.bind(('192.168.1.199',0))
end=time.monotonic()+20;n=0;errors=0
while time.monotonic()<end:
 try:s.sendto(b'routeprobe',('192.168.1.171',9999));n+=1
 except OSError:errors+=1
 time.sleep(.002)
print('sent',n,'errors',errors,flush=True)
