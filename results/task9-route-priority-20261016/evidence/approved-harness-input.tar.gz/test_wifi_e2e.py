import os
import signal
import sys
import tempfile
import time
from pathlib import Path

import pytest

from openpilot.system.ui.lib.wifi_manager import SCAN_PERIOD_SECONDS, UDHCPC_SCRIPT_PATH
from wifi_e2e import PROFILE_DIR, SERVER, WifiLab, keyfile_profiles, run


pytestmark = pytest.mark.skipif(os.environ.get('WIFI_E2E') != '1', reason='requires run_wifi_e2e.sh in a disposable Linux VM')


@pytest.fixture
def lab():
  value = WifiLab()
  try:
    value.setup()
    yield value
  finally:
    try:
      value.diagnostics()
    finally:
      value.cleanup()


def start_connected(lab):
  lab.ap()
  identifier = lab.seed()
  lab.start_manager()
  lab.connected('Test A')
  return identifier


def assert_forgotten(lab, ssid):
  state = lab.wait(lambda _: ['forgotten', ssid] in lab.events)
  assert not state['saved'][ssid], 'UI received forgotten, but the manager still considers the network saved'
  assert ssid not in [profile[1] for profile in keyfile_profiles().values()], 'A persistent/runtime keyfile survived Forget'
  assert ssid not in run('wpa_cli', '-p', '/run/wpa_supplicant', '-i', 'wlan0', 'list_networks', ns=lab.names['dut']).stdout


def test_empty_scan(lab):
  lab.start_manager()
  lab.call('set_active', True)
  state = lab.wait(lambda _: ['networks_updated'] in lab.events)
  assert state['networks'] == []
  assert state['connected'] is None and not state['ip']


@pytest.mark.parametrize('ssid,password,hidden', [
  ('Open', '', False),
  ('Test A', 'password123', False),
  ('Hidden', 'password123', True),
  ('Hidden open', '', True),
  ('București', 'parolă-123', False),
  ('S' * 32, 'password123', False),
  ('Test A', '12345678', False),
  ('Test A', 'p' * 63, False),
  ('Test A', 'ab' * 32, False),
  ('Test A', ' pass\\word" ', False),
])
def test_connect_persist_and_reopen(lab, ssid, password, hidden):
  lab.ap(ssid, password, hidden=hidden)
  lab.start_manager()
  lab.call('connect_to_network', ssid, password, hidden=hidden)
  state = lab.connected(ssid)
  assert state['saved'][ssid]
  profiles = [(identifier, cp) for identifier, name, cp in keyfile_profiles().values() if name == ssid]
  assert len(profiles) == 1
  identifier, _ = profiles[0]
  run('nmcli', 'connection', 'reload', ns=lab.names['dut'])
  assert identifier in run('nmcli', '-g', 'UUID', 'connection', 'show', ns=lab.names['dut']).stdout.splitlines()
  if password:
    result = run('nmcli', '--escape', 'no', '--show-secrets', '-g', '802-11-wireless-security.psk', 'connection', 'show', identifier, ns=lab.names['dut'])
    assert result.stdout.rstrip('\n') == password
  lab.stop_manager()
  lab.start_manager()
  assert lab.connected(ssid)['saved'][ssid]
  assert identifier in [entry[0] for entry in keyfile_profiles().values()]


def test_wrong_password_then_retry(lab):
  lab.ap()
  lab.start_manager()
  lab.call('connect_to_network', 'Test A', 'incorrect123')
  state = lab.wait(lambda _: ['need_auth', 'Test A'] in lab.events)
  assert not state['saved']['Test A']
  assert 'Test A' not in [entry[1] for entry in keyfile_profiles().values()]
  lab.call('connect_to_network', 'Test A', 'password123')
  lab.connected('Test A')


def test_forget_cancels_pending_hidden_connection(lab):
  lab.start_manager()
  lab.call('connect_to_network', 'Missing', 'password123', hidden=True)
  lab.wait(lambda s: s['connecting'] == 'Missing')
  lab.events.clear()
  lab.call('forget_connection', 'Missing')
  assert_forgotten(lab, 'Missing')
  lab.stop_manager()
  assert not lab.start_manager()['saved']['Missing']


def test_switch_saved_networks_replaces_lease(lab):
  start_connected(lab)
  lab.ap('Test B', index=1)
  lab.call('connect_to_network', 'Test B', 'password123')
  assert lab.connected('Test B')['ip'].startswith('10.20.0.')
  lab.call('activate_connection', 'Test A')
  assert lab.connected('Test A')['ip'].startswith('10.10.0.')
  lab.call('activate_connection', 'Test B')
  assert lab.connected('Test B')['ip'].startswith('10.20.0.')
  scan_started = time.monotonic()
  lab.events.clear()
  lab.call('set_active', True)
  state = lab.wait(lambda _: time.monotonic() - scan_started >= SCAN_PERIOD_SECONDS and
                   lab.events.count(['networks_updated']) >= 2, timeout=12)
  assert state['connected'] == 'Test B' and state['ip'].startswith('10.20.0.')
  assert 'dev wlan0' in run('ip', 'route', 'get', SERVER, ns=lab.names['dut']).stdout
  lab.http('dut', 'wlan0')


@pytest.mark.parametrize('source', ['keyfile', 'shadow', 'netplan'])
@pytest.mark.parametrize('active', [False, True])
def test_forget_removes_every_persistent_source(lab, source, active):
  lab.ap()
  lab.ap('Test B', index=1)
  identifier = lab.seed(source=source)
  other = lab.seed('Test B', priority=0)
  lab.start_manager()
  lab.connected('Test A')
  if not active:
    lab.call('activate_connection', 'Test B')
    lab.connected('Test B')
  lab.events.clear()
  lab.call('forget_connection', 'Test A')
  assert_forgotten(lab, 'Test A')
  lab.connected('Test B')
  assert other in [entry[0] for entry in keyfile_profiles().values()]
  lab.stop_manager()
  # Recreating generated profiles must not resurrect the forgotten network.
  run('netplan', 'generate')
  run('nmcli', 'connection', 'reload', ns=lab.names['dut'])
  assert identifier not in run('nmcli', '-g', 'UUID', 'connection', 'show', ns=lab.names['dut']).stdout.splitlines()
  lab.start_manager()
  assert not lab.connected('Test B')['saved']['Test A']


def test_forget_duplicate_profiles_for_one_ui_entry(lab):
  lab.ap()
  identifiers = {lab.seed(), lab.seed(priority=0)}
  lab.start_manager()
  lab.connected('Test A')
  lab.events.clear()
  lab.call('forget_connection', 'Test A')
  assert_forgotten(lab, 'Test A')
  assert not identifiers.intersection(entry[0] for entry in keyfile_profiles().values())
  lab.events.clear()
  lab.call('forget_connection', 'Test A')
  assert_forgotten(lab, 'Test A')


def test_failed_forget_preserves_profile_and_emits_forgotten(lab):
  start_connected(lab)
  lab.call('set_active', False)
  before = {str(path): path.read_bytes() for path in PROFILE_DIR.glob('*.nmconnection')}
  lab.events.clear()
  with lab.readonly_profiles():
    lab.call('forget_connection', 'Test A')
    state = lab.wait(lambda _: ['forgotten', 'Test A'] in lab.events)
    assert state['saved']['Test A']
    assert {str(path): path.read_bytes() for path in PROFILE_DIR.glob('*.nmconnection')} == before


@pytest.mark.parametrize('metered', [0, 1, 2])
def test_metering_persists_and_matches_runtime_identity(lab, metered):
  identifier = start_connected(lab)
  state = lab.call_setter('set_current_network_metered', metered)
  assert state['metered'] == metered
  run('nmcli', 'connection', 'reload', ns=lab.names['dut'])
  value = run('nmcli', '-g', 'connection.metered', 'connection', 'show', identifier, ns=lab.names['dut']).stdout.strip()
  assert value in ({'unknown', '0'}, {'yes', '1'}, {'no', '2'})[metered]
  lab.stop_manager()
  lab.start_manager()
  assert lab.connected('Test A')['metered'] == metered


def test_failed_metering_preserves_saved_policy(lab):
  start_connected(lab)
  lab.call('set_active', False)
  lab.events.clear()
  with lab.readonly_profiles():
    state = lab.call_setter('set_current_network_metered', 1)
    assert state['metered'] == 0
  lab.stop_manager()
  lab.start_manager()
  assert lab.connected('Test A')['metered'] == 0


def test_navigation_does_not_disconnect(lab):
  start_connected(lab)
  pid_file = Path('/run/wpa_supplicant/wlan0.pid')
  pid = pid_file.read_text()
  for active in (False, True, False, True):
    lab.call('set_active', active)
    lab.connected('Test A')
    assert pid_file.read_text() == pid


def test_dhcp_timeout_then_another_selection(lab):
  lab.ap(dhcp=False)
  lab.start_manager()
  lab.call('connect_to_network', 'Test A', 'password123')
  state = lab.wait(lambda _: ['disconnected'] in lab.events, timeout=50)
  assert state['connected'] is None and not state['ip']
  lab.ap('Test B', index=1)
  lab.call('connect_to_network', 'Test B', 'password123')
  lab.connected('Test B')


@pytest.mark.parametrize('crash', [False, True])
def test_manager_restart_preserves_working_station(lab, crash):
  start_connected(lab)
  files = [Path('/run/wpa_supplicant/wlan0.pid'), Path('/run/udhcpc.wlan0.pid')]
  pids = [path.read_text() for path in files]
  lab.stop_manager(crash=crash)
  lab.http('dut', 'wlan0')
  lab.start_manager()
  lab.connected('Test A')
  assert [path.read_text() for path in files] == pids


def test_udhcpc_connected_prefix_loses_to_wired_shared_subnet(lab):
  dut, wan = lab.names['dut'], lab.names['wan']
  run('ip', 'route', 'del', 'default', 'via', '10.200.1.1', 'dev', 'wwan0', 'metric', '700', ns=dut)
  run('ip', 'addr', 'del', '10.200.1.2/24', 'dev', 'wwan0', ns=dut)
  run('ip', 'addr', 'del', '10.200.1.1/24', 'dev', 'wan1', ns=wan)
  run('ip', 'addr', 'add', '192.168.1.2/24', 'dev', 'wwan0', ns=dut)
  run('ip', 'addr', 'add', '192.168.1.1/24', 'dev', 'wan1', ns=wan)
  run('ip', 'route', 'del', '192.168.1.0/24', 'dev', 'wwan0', ns=dut)
  run('ip', 'route', 'add', '192.168.1.0/24', 'dev', 'wwan0', 'metric', '100', ns=dut)
  run('ip', 'route', 'add', 'default', 'via', '192.168.1.1', 'dev', 'wwan0', 'metric', '100', ns=dut)
  wired_prefix = run('busybox', 'ip', '-4', 'route', 'show', 'dev', 'wwan0', 'proto', 'kernel', 'scope', 'link', ns=dut).stdout.splitlines()
  assert [line.split() for line in wired_prefix] == [['192.168.1.0/24', 'dev', 'wwan0', 'metric', '100']]

  hook_env = ('UDHCPC_DEFAULT_SCRIPT=/etc/udhcpc/default.script', 'interface=wlan0', 'ip=192.168.1.3',
              'subnet=255.255.255.0', 'router=192.168.1.1', 'dns=198.18.0.2')
  run('env', *hook_env, UDHCPC_SCRIPT_PATH, 'bound', ns=dut)

  lookup = run('ip', '-4', 'route', 'get', '192.168.1.1', 'from', '192.168.1.2', ns=dut).stdout
  assert 'dev wwan0' in lookup, lookup
  wlan_prefix = run('busybox', 'ip', '-4', 'route', 'show', 'dev', 'wlan0', 'proto', 'kernel', 'scope', 'link', ns=dut).stdout.splitlines()
  assert [line.split() for line in wlan_prefix] == [['192.168.1.0/24', 'dev', 'wlan0', 'src', '192.168.1.3', 'metric', '600']]
  assert run('busybox', 'ip', '-4', 'route', 'show', 'dev', 'wwan0', 'proto', 'kernel', 'scope', 'link', ns=dut).stdout.splitlines() == wired_prefix
  defaults = [line.split() for line in run('busybox', 'ip', '-4', 'route', 'show', 'default', ns=dut).stdout.splitlines()]
  assert defaults == [['default', 'via', '192.168.1.1', 'dev', 'wwan0', 'metric', '100'],
                      ['default', 'via', '192.168.1.1', 'dev', 'wlan0', 'metric', '600']]

  run('ip', 'route', 'add', '203.0.113.0/24', 'via', '192.168.1.1', 'dev', 'wlan0', ns=dut)
  run('env', *hook_env, UDHCPC_SCRIPT_PATH, 'renew', ns=dut)
  assert run('busybox', 'ip', '-4', 'route', 'show', '203.0.113.0/24', ns=dut).stdout.split() == [
    '203.0.113.0/24', 'via', '192.168.1.1', 'dev', 'wlan0']
  assert run('busybox', 'ip', '-4', 'route', 'show', 'dev', 'wlan0', 'proto', 'kernel', 'scope', 'link', ns=dut).stdout.splitlines() == wlan_prefix
  assert [line.split() for line in run('busybox', 'ip', '-4', 'route', 'show', 'default', ns=dut).stdout.splitlines()] == defaults
  assert run('busybox', 'ip', '-4', 'route', 'show', 'dev', 'wwan0', 'proto', 'kernel', 'scope', 'link', ns=dut).stdout.splitlines() == wired_prefix

  run('ip', 'link', 'set', 'wlan0', 'down', ns=dut)
  down_lookup = run('ip', '-4', 'route', 'get', '192.168.1.1', 'from', '192.168.1.2', ns=dut).stdout
  assert 'dev wwan0' in down_lookup, down_lookup


def test_wifi_lte_priority_and_ap_loss(lab):
  start_connected(lab)
  assert 'dev wlan0' in run('ip', 'route', 'get', SERVER, ns=lab.names['dut']).stdout
  ap = lab.access_points[0][0]
  ap.terminate()
  ap.wait(timeout=5)
  lab.wait_external(lambda: 'dev wwan0' in run('ip', 'route', 'get', SERVER, ns=lab.names['dut']).stdout, timeout=35)
  lab.http('dut', 'wwan0')
  lab.ap()
  lab.connected('Test A')
  assert 'dev wlan0' in run('ip', 'route', 'get', SERVER, ns=lab.names['dut']).stdout


@pytest.mark.parametrize('pid_path', ['/run/wpa_supplicant/wlan0.pid', '/run/udhcpc.wlan0.pid'])
def test_connected_service_failure_recovers(lab, pid_path):
  start_connected(lab)
  path = Path(pid_path)
  old_pid = path.read_text()
  os.kill(int(old_pid), signal.SIGKILL)
  def recovered():
    if not path.exists() or path.read_text() == old_pid:
      return False
    route = run('ip', '-4', 'route', 'show', 'default', 'dev', 'wlan0', ns=lab.names['dut']).stdout
    resolver = run('cat', '/etc/resolv.conf', ns=lab.names['dut']).stdout
    if 'metric 600' not in route or 'linkdown' in route or f'nameserver {SERVER}' not in resolver:
      return False
    try:
      lab.http('dut', 'wlan0')
    except AssertionError:
      return False
    return True

  lab.wait_external(recovered, timeout=35)
  state = lab.connected('Test A')
  assert state['status'] == 2


def test_station_tethering_station_and_forwarding(lab):
  start_connected(lab)
  lab.call('set_ipv4_forward', True)
  lab.call('set_tethering_active', True)
  state = lab.wait(lambda s: s['tethering'] and s['ip'] == '192.168.43.1')
  lab.client(state['connected'], state['password'])
  lab.http('client', 'wlan0')
  lab.call('set_ipv4_forward', False)
  lab.wait_external(lambda: run('sysctl', '-n', 'net.ipv4.ip_forward', ns=lab.names['dut']).stdout.strip() == '0')
  lab.http('client', 'wlan0', success=False)
  lab.call('set_ipv4_forward', True)
  lab.wait_external(lambda: run('sysctl', '-n', 'net.ipv4.ip_forward', ns=lab.names['dut']).stdout.strip() == '1')
  lab.http('client', 'wlan0')
  lab.stop_manager(crash=True)
  lab.http('client', 'wlan0')
  lab.start_manager()
  lab.wait(lambda s: s['tethering'])
  lab.call('set_tethering_active', False)
  lab.connected('Test A')
  assert not Path('/run/dnsmasq.wlan0.pid').exists()
  assert 'openpilot-tethering' not in run('iptables-legacy-save', ns=lab.names['dut']).stdout


@pytest.mark.parametrize('active', [False, True])
@pytest.mark.parametrize('password', ['z' * 64, '🙂' * 16])
def test_rejected_tethering_password_completes_ui(lab, active, password):
  start_connected(lab)
  lab.call('set_active', False)
  if active:
    lab.call('set_tethering_active', True)
    lab.wait(lambda s: s['tethering'])
  old = lab.call('snapshot')['password']
  lab.events.clear()
  state = lab.call_setter('set_tethering_password', password)
  assert state['password'] == old
  assert state['tethering'] == active


@pytest.mark.parametrize('active', [False, True])
def test_tethering_password_change_and_noop(lab, active):
  start_connected(lab)
  lab.call('set_active', False)
  if active:
    lab.call('set_tethering_active', True)
    lab.wait(lambda s: s['tethering'])
  password = 'new-password123'
  state = lab.call_setter('set_tethering_password', password)
  assert state['password'] == password
  lab.events.clear()
  state = lab.call_setter('set_tethering_password', password)
  assert state['password'] == password
  lab.stop_manager()
  lab.start_manager()
  lab.wait(lambda s: s['password'] == password)
  if not active:
    lab.call('set_tethering_active', True)
  state = lab.wait(lambda s: s['tethering'])
  lab.client(state['connected'], password)


def test_hidden_connection_requested_while_tethering_completes(lab):
  start_connected(lab)
  lab.call('set_tethering_active', True)
  lab.wait(lambda s: s['tethering'])
  lab.events.clear()
  lab.call('connect_to_network', 'Missing', 'password123', hidden=True)
  state = lab.wait(lambda s: not s['tethering'] and s['connecting'] == 'Missing')
  assert state['status'] == 1 and not state['saved']['Missing']


@pytest.mark.parametrize('password', ['z' * 64, '🙂' * 16])
def test_rejected_station_password_completes_ui(lab, password):
  lab.ap()
  lab.start_manager()
  lab.call('connect_to_network', 'Test A', password)
  state = lab.wait(lambda _: ['need_auth', 'Test A'] in lab.events)
  assert not state['saved']['Test A'] and state['connected'] is None
  assert 'Test A' not in [entry[1] for entry in keyfile_profiles().values()]


def test_saved_profile_auth_failure_preserves_working_profile(lab):
  start_connected(lab)
  lab.ap(password='incorrect123')
  before = {str(path): path.read_bytes() for path in PROFILE_DIR.glob('*.nmconnection')}
  lab.events.clear()
  lab.call('activate_connection', 'Test A')
  lab.wait(lambda _: ['need_auth', 'Test A'] in lab.events)
  assert {str(path): path.read_bytes() for path in PROFILE_DIR.glob('*.nmconnection')} == before
  lab.ap()
  lab.call('activate_connection', 'Test A')
  lab.connected('Test A')


def test_password_replacement_forgets_previous_profile_before_auth_failure(lab):
  start_connected(lab)
  lab.events.clear()
  lab.call('connect_to_network', 'Test A', 'incorrect123', hidden=True)
  state = lab.wait(lambda _: ['need_auth', 'Test A'] in lab.events)
  assert not state['saved']['Test A']
  assert 'Test A' not in [entry[1] for entry in keyfile_profiles().values()]


def test_new_profile_write_failure_leaves_station_connected_without_profile(lab):
  lab.ap()
  lab.start_manager()
  with lab.readonly_profiles():
    lab.call('connect_to_network', 'Test A', 'password123')
    state = lab.wait(lambda s: ['save_failed', 'Test A'] in lab.events and s['connected'] == 'Test A' and bool(s['ip']))
    assert not state['saved']['Test A']
    assert ['activated'] not in lab.events
    assert 'Test A' not in [entry[1] for entry in keyfile_profiles().values()]
    lab.http('dut', 'wlan0')


def test_new_selection_supersedes_pending_connection(lab):
  lab.ap()
  lab.seed()
  lab.start_manager()
  lab.connected('Test A')
  lab.call('connect_to_network', 'Missing', 'password123', hidden=True)
  lab.wait(lambda s: s['connecting'] == 'Missing')
  lab.call('activate_connection', 'Test A')
  state = lab.connected('Test A')
  assert not state['saved']['Missing']
  assert 'Missing' not in [entry[1] for entry in keyfile_profiles().values()]


@pytest.mark.parametrize('connecting', [False, True])
def test_tethering_without_an_active_station(lab, connecting):
  lab.start_manager()
  if connecting:
    lab.call('connect_to_network', 'Missing', 'password123', hidden=True)
    lab.wait(lambda s: s['connecting'] == 'Missing')
  lab.call('set_ipv4_forward', True)
  lab.call('set_tethering_active', True)
  state = lab.wait(lambda s: s['tethering'] and bool(s['ip']))
  lab.client(state['connected'], state['password'])
  lab.http('client', 'wlan0')
  lab.call('set_tethering_active', False)
  state = lab.wait(lambda s: not s['tethering'])
  assert not state['connected']


@pytest.mark.parametrize('active', [False, True])
def test_failed_tethering_password_write_keeps_previous_password(lab, active):
  start_connected(lab)
  lab.call('set_active', False)
  if active:
    lab.call('set_tethering_active', True)
    lab.wait(lambda s: s['tethering'])
  old = lab.call('snapshot')['password']
  lab.events.clear()
  with lab.readonly_profiles():
    state = lab.call_setter('set_tethering_password', 'new-password123')
    assert state['password'] == old and state['tethering'] == active
  lab.stop_manager()
  lab.start_manager()
  lab.wait(lambda s: s['password'] == old)
  if active:
    state = lab.wait(lambda s: s['tethering'])
    lab.client(state['connected'], old)
  else:
    lab.connected('Test A')


def test_networkmanager_works_before_ui_and_after_explicit_handoff(lab):
  lab.ap()
  identifier = lab.seed()
  run('nmcli', '--wait', '20', 'connection', 'up', identifier, ns=lab.names['dut'])
  lab.http('dut', 'wlan0')
  lab.start_manager()
  lab.connected('Test A')
  lab.call('set_current_network_metered', 1)
  lab.wait(lambda s: s['metered'] == 1)
  lab.stop_manager()
  # v3 never hands wlan0 back by itself; this is the documented rollback: stop the daemons, let NetworkManager manage wlan0 again
  pids = []
  for pid_file in ('/run/dnsmasq.wlan0.pid', '/run/udhcpc.wlan0.pid', '/run/wpa_supplicant/wlan0.pid'):
    path = Path(pid_file)
    if path.exists():
      pid = int(path.read_text())
      os.kill(pid, signal.SIGTERM)
      pids.append(pid)

  def stopped(pid):
    try:
      state = Path(f'/proc/{pid}/stat').read_text().rpartition(') ')[2].split(maxsplit=1)[0]
    except FileNotFoundError:
      return True
    return state == 'Z'

  lab.wait_external(lambda: all(stopped(pid) for pid in pids))
  lab.wait_external(lambda: not Path('/run/wpa_supplicant/wlan0').exists())
  run('nmcli', 'device', 'set', 'wlan0', 'managed', 'yes', ns=lab.names['dut'])

  def networkmanager_ready():
    state = run('nmcli', '-g', 'GENERAL.STATE', 'device', 'show', 'wlan0', ns=lab.names['dut'], check=False).stdout.strip()
    return state.partition(' ')[0] in {'30', '40', '50', '60', '70', '80', '90', '100'}

  lab.wait_external(networkmanager_ready)
  run('nmcli', 'connection', 'reload', ns=lab.names['dut'])
  run('nmcli', '--wait', '20', 'connection', 'up', identifier, ns=lab.names['dut'])
  lab.http('dut', 'wlan0')
  value = run('nmcli', '-g', 'connection.metered', 'connection', 'show', identifier, ns=lab.names['dut']).stdout.strip()
  assert value in ('yes', '1')


@pytest.mark.parametrize('mode', ['no-nm', 'nm'])
def test_route_priority_during_dhcp(mode, tmp_path):
  assert os.geteuid() == 0 and os.environ.get('WIFI_E2E_VM') == '1' and not Path('/AGNOS').exists()
  directory = tempfile.mkdtemp(prefix=f'route-{mode}-', dir=os.environ.get('WIFI_E2E_LOG_DIR', str(tmp_path)))
  worker = Path(__file__).with_name('wifi_e2e.py')
  result = run('unshare', '-m', '--propagation', 'private', 'env', f'UDHCPC_SCRIPT_PATH={UDHCPC_SCRIPT_PATH}',
      f"WIFI_E2E_OUTER_MNT={os.readlink('/proc/self/ns/mnt')}",
               sys.executable, str(worker), '--route-priority', mode, directory, check=False)
  assert result.returncode == 0, f'child stdout:\n{result.stdout}\nchild stderr:\n{result.stderr}'
