#!/bin/sh
set -eu
if [ "no-nm" = no-nm ]; then
  mount -t tmpfs tmpfs /run
  mount --bind /workspace/openpilot-wifi-validation/task-results/full/route-no-nm-cu0hb6wr/trial/absent /usr/bin/nmcli
  mount --bind /workspace/openpilot-wifi-validation/task-results/full/route-no-nm-cu0hb6wr/trial/absent /usr/sbin/NetworkManager
  test ! -x /usr/bin/nmcli
  test ! -x /usr/sbin/NetworkManager
  test ! -S /run/dbus/system_bus_socket
fi
if [ "${DNS_FALLBACK:-0}" = 1 ]; then
  mount --bind /workspace/openpilot-wifi-validation/task-results/full/route-no-nm-cu0hb6wr/trial/absent /usr/bin/resolvectl
fi
if [ ! -e /run/systemd/resolve/stub-resolv.conf ]; then
  mkdir -p $(dirname /run/systemd/resolve/stub-resolv.conf)
  touch /run/systemd/resolve/stub-resolv.conf
fi
mount --bind /workspace/openpilot-wifi-validation/task-results/full/route-no-nm-cu0hb6wr/trial/resolv.conf /run/systemd/resolve/stub-resolv.conf
exec /workspace/openpilot-wifi-validation/task-results/full/route-no-nm-cu0hb6wr/trial/udhcpc.script "$1"
