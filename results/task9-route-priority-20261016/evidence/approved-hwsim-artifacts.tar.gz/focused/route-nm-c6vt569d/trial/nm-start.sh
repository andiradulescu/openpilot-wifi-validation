set -eu
    mount -t tmpfs tmpfs /run
    mkdir -p /run/udev/data
    mount --bind /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/udev-data /run/udev/data
    mount -o remount,bind,ro /run/udev/data
    mount --bind /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/etcNM /etc/NetworkManager
    mount --bind /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/varlib /var/lib/NetworkManager
    mount --bind /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/empty /etc/netplan
    dbus-daemon --system --nofork --nopidfile --address=unix:abstract=wifi-route-1066 > /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/dbus.log 2>&1 &
    export DBUS_SYSTEM_BUS_ADDRESS=unix:abstract=wifi-route-1066
    exec strace -f -ttt -s 512 -e trace=sendmsg,recvmsg,ioctl -o /workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/nm.strace \
      NetworkManager --no-daemon --debug --config=/workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/nm.conf --config-dir=/workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/empty \
      --system-config-dir=/workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/empty --pid-file=/workspace/openpilot-wifi-validation/task-results/focused/route-nm-c6vt569d/trial/nm.pid --log-level=TRACE --log-domains=PLATFORM,IP4,DEVICE,DHCP4,CORE
    